from typing import Iterable
from quizapi.core.domain.player import Player, PlayerIn
from quizapi.core.repositories.iplayer import IPlayerRepository
from quizapi.infrastructure.dto.playerdto import PlayerDTO
from quizapi.infrastructure.services.iplayer import IPlayerService

class PlayerService(IPlayerService):

    _repository: IPlayerRepository

    def __init__(self, repository: IPlayerRepository):

        self._repository = repository

    async def get_all_players(self) -> Iterable[PlayerDTO]:
        return await self._repository.get_all_players()

    async def get_player_by_id(self, player_id: int) -> Player | None:
        return await self._repository.get_player_by_id(player_id)

    async def add_player(self, data: PlayerIn) -> None:
        return await self._repository.add_player(data)

    async def update_player(
            self,
            player_id: int,
            data: PlayerIn
    ) -> Player | None:
        return await self._repository.update_player(
            player_id=player_id,
            data=data,
        )

    async def delete_player(self, player_id: int) -> bool:
        return await self._repository.delete_player(player_id)