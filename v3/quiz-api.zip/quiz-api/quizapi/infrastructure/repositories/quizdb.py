from typing import Any, Iterable
from asyncpg import Record # type: ignore
from sqlalchemy import select, join
from quizapi.core.repositories.iquiz import IQuizRepository
from quizapi.core.domain.quiz import Quiz, QuizIn
from quizapi.db import quiz_table, database
from quizapi.infrastructure.dto.quizdto import QuizDTO


class QuizRepository(IQuizRepository):

    async def get_all_quizzes(self) -> Iterable[Any]:
        query = quiz_table.select().order_by(quiz_table.c.id.asc()) # bylo quiz_id zamiast id
        quizzes = await database.fetch_all(query)
        return [Quiz(**dict(quiz)) for quiz in quizzes]

    async def get_quiz_by_id(self, quiz_id: int) -> Record | None:
        quiz = await self._get_by_id(quiz_id)
        return Quiz(**dict(quiz)) if quiz else None

    async def add_quiz(self, data: QuizIn) -> Any | None:
        query = quiz_table.insert().values(**data.model_dump())
        new_quiz_id = await database.execute(query)
        new_quiz = await self._get_by_id(new_quiz_id)
        return Quiz(**dict(new_quiz)) if new_quiz else None

    async def update_quiz(
            self,
            quiz_id: int,
            data: QuizIn,
    ) -> Any | None:
        if self._get_by_id(quiz_id):
            query = quiz_table.update().where(quiz_table.c.id == quiz_id).values(**data.model_dump())
            await database.execute(query)
            quiz = await self._get_by_id(quiz_id)
            return Quiz(**dict(quiz)) if quiz else None
        return None

    async def delete_quiz(self, quiz_id: int) -> bool:
        if self._get_by_id(quiz_id):
            query = quiz_table.delete().where(quiz_table.c.id == quiz_id)
            await database.execute(query)
            return True
        return False

    async def _get_by_id(self, quiz_id: int) -> Record | None:
        query = quiz_table.select().where(quiz_table.c.id == quiz_id).order_by(quiz_table.c.title.asc()) # tu bylo name zamiast title
        return await database.fetch_one(query)
