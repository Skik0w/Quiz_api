quizzes: list = []
questions: list = []
players: list = []